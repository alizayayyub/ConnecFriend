/* theme.js - colour themes (White, Neon Dark, Ocean, Sunset, Forest)
   Loaded in <head>, so the saved theme is used before the page is drawn.
   The colours themselves are in css/style.css (the THEMES block). */

// name of each theme, and whether Bootstrap should use its light or dark mode
const THEMES = {
    neon:   { label: "🌙 Neon Dark", mode: "dark" },
    white:  { label: "☀️ White",     mode: "light" },
    ocean:  { label: "🌊 Ocean",     mode: "dark" },
    sunset: { label: "🌅 Sunset",    mode: "dark" },
    forest: { label: "🌲 Forest",    mode: "dark" }
};

// The theme saved in this browser (or Neon Dark if none)
function currentTheme() {
    let saved = null;
    try {
        saved = localStorage.getItem("cf_theme");
    } catch (e) {
        saved = null;                    // storage blocked: use the default
    }
    return THEMES[saved] ? saved : "neon";
}

// Change the colours of the page (and Bootstrap's light/dark mode)
function applyTheme(name) {
    const root = document.documentElement;
    root.setAttribute("data-theme", name);
    root.setAttribute("data-bs-theme", THEMES[name].mode);
}

// Called by the theme picker on every page
function setTheme(name) {
    if (!THEMES[name]) return;           // unknown theme: do nothing
    applyTheme(name);
    try {
        localStorage.setItem("cf_theme", name);
    } catch (e) {
        // storage blocked: the theme still changes, it just is not remembered
    }
}

applyTheme(currentTheme());

// Fill every theme picker on the page with the list of themes
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("#themePicker").forEach(picker => {
        picker.innerHTML = Object.keys(THEMES)
            .map(k => `<option value="${k}">${THEMES[k].label}</option>`).join("");
        picker.value = currentTheme();
    });
});
