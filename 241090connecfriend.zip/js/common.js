/* common.js - shared by Home, Profile and Messages */

// If nobody is logged in, go back to the login page
if (localStorage.getItem("loggedIn") === null) {
    window.location.href = "index.html";
}

const ME = "Alizay Ayyub";

// ----- helpers for localStorage -----
function load(key, fallback) {
    try {
        const v = JSON.parse(localStorage.getItem(key));
        return v === null ? fallback : v;
    } catch (e) {
        return fallback;
    }
}

function save(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
        alert("Could not save. Browser storage is full or blocked.");
    }
}

// Logout: remove the "logged in" flag and go back to the login page
function logout() {
    localStorage.removeItem("loggedIn");
    window.location.href = "index.html";
}

// Show a Bootstrap alert at the top of the page (type: success, warning, danger)
function showAlert(text, type) {
    const box = document.getElementById("alertBox");
    box.innerHTML = `<div class="alert alert-${type} py-2">${text}</div>`;
    setTimeout(() => { box.innerHTML = ""; }, 3000);
}

// Make text safe before putting it in HTML
function safe(text) {
    const d = document.createElement("div");
    d.textContent = text;
    return d.innerHTML;
}

// "10 minutes ago", "2 hours ago" ...
function timeAgo(time) {
    const mins = Math.floor((Date.now() - time) / 60000);
    if (mins < 1) return "just now";
    if (mins < 60) return mins + " min ago";
    if (mins < 1440) return Math.floor(mins / 60) + " hour(s) ago";
    return Math.floor(mins / 1440) + " day(s) ago";
}

// ----- friends (saved once, so login times stay the same) -----
function getFriends() {
    let list = load("friends", null);
    if (list === null) {
        const now = Date.now();
        list = [
            { name: "Sarah Khan",     seen: now - 10 * 60000 },
            { name: "Hassan Ali",     seen: now - 35 * 60000 },
            { name: "Noor Fatima",    seen: now - 60 * 60000 },
            { name: "Muhammad Hamza", seen: now - 240 * 60000 }
        ];
        save("friends", list);
    }
    return list;
}

// friends with the latest login first
function friendsByLogin() {
    return getFriends().slice().sort((a, b) => b.seen - a.seen);
}

// Other members of the site (not friends yet)
const OTHER_MEMBERS = ["Maryam Sheikh", "Bilal Ahmed", "Hira Saeed", "Daniyal Shah"];

// These people have put ME in their ignore list
const IGNORE_LIST = ["Bilal Ahmed", "Daniyal Shah"];

// First letter in a maroon circle, used instead of a picture
function avatar(name) {
    return `<span class="rounded-circle bg-maroon text-white d-inline-flex align-items-center justify-content-center fw-bold me-2" style="width:40px;height:40px;">${safe(name[0])}</span>`;
}

// ----- navbar (same on every page) -----
document.getElementById("navbar").innerHTML = `
<nav class="navbar navbar-expand-sm bg-maroon navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="home.html">ConnecFriend</a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#menu"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="menu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="home.html">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="profile.html">Profile</a></li>
        <li class="nav-item"><a class="nav-link" href="messages.html">Messages</a></li>
        <li class="nav-item"><button class="btn btn-gold btn-sm ms-lg-3 mt-1 mt-lg-0" onclick="logout()"><i class="bi bi-box-arrow-right"></i> Logout</button></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-3" id="alertBox"></div>`;
