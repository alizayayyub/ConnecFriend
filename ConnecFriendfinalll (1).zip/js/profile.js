/* profile.js - only for the profile page */

const RATINGS_KEY = "cf_ratings";                                   // my ratings of friends
const RATE_COLORS = ["", "bg-danger", "bg-warning", "bg-success"];  // Stupid, Cool, Trustworthy


/* ---------- Profile photo ---------- */

// Show my uploaded photo, or my drawn cartoon if I have not uploaded one
function paintProfilePic() {
    const photo = readStore(PHOTO_KEY, null);
    document.getElementById("profilePic").innerHTML = photo
        ? `<img class="avatar-img" src="${photo}" alt="Profile photo">`
        : figure(PEOPLE[ME], "wait", "18 6 84 84");
}

// Choose a photo: must be an image under 5 MB. It is cut to a square and saved small.
function uploadPhoto(input) {
    const file = input.files[0];
    if (!file) return;                                    // user cancelled

    // Error handling
    if (!file.type.startsWith("image/")) {
        showMessage("Please choose an image file (JPG or PNG).", "danger");
        return;
    }
    if (file.size > 5 * 1024 * 1024) {
        showMessage("This image is too big. Please choose one under 5 MB.", "danger");
        return;
    }

    const img = new Image();
    img.onload = function () {
        const size = 200;
        const side = Math.min(img.width, img.height);       // biggest square in the middle
        const canvas = document.createElement("canvas");
        canvas.width = size;
        canvas.height = size;
        canvas.getContext("2d").drawImage(img,
            (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, size, size);
        URL.revokeObjectURL(img.src);

        if (writeStore(PHOTO_KEY, canvas.toDataURL("image/jpeg", 0.85))) {
            paintProfilePic();
            showMessage("Profile photo updated ✨", "success");
        }
    };
    img.onerror = function () {
        showMessage("This image could not be opened.", "danger");
    };
    img.src = URL.createObjectURL(file);
}


/* ---------- Friends with rating ---------- */

// Friend list, newest login first (drawn from the saved friend list)
function renderProfileFriends() {
    const list = friendsByLogin();
    document.getElementById("friendCount").textContent = list.length;

    document.getElementById("profileFriends").innerHTML = list.map(f => `
        <div class="friend-row" data-name="${esc(f.name)}">
            <div class="d-flex align-items-center">
                ${bust(f.name, "sm")}
                <div class="ms-3 flex-grow-1">
                    <strong>${esc(f.name)}</strong>
                    <small class="d-block text-secondary">${f.mutual} mutual friend${f.mutual === 1 ? "" : "s"}</small>
                </div>
                <div>
                    <button class="rate-btn" title="Stupid" onclick="rateFriend(this, 1)"><i class="bi bi-emoji-dizzy"></i></button>
                    <button class="rate-btn" title="Cool" onclick="rateFriend(this, 2)"><i class="bi bi-emoji-sunglasses"></i></button>
                    <button class="rate-btn" title="Trustworthy" onclick="rateFriend(this, 3)"><i class="bi bi-shield-check"></i></button>
                </div>
            </div>
            <div class="d-flex align-items-center mt-2">
                <small class="text-secondary me-2">Trust meter</small>
                <div class="progress flex-grow-1" style="height: 8px;">
                    <div class="progress-bar" style="width: 0%"></div>
                </div>
                <small class="trust-label ms-2" style="min-width: 80px;">Not rated</small>
            </div>
        </div>`).join("");

    // show the ratings that were saved before
    const ratings = readStore(RATINGS_KEY, {});
    document.querySelectorAll("#profileFriends .friend-row").forEach(row => {
        const level = ratings[row.dataset.name];
        if (level) paintRating(row, level);
    });
}

// Colour the trust meter and show the rating name, for one friend row
function paintRating(row, level) {
    row.querySelectorAll(".rate-btn").forEach((btn, i) => {
        btn.classList.toggle("active", i + 1 === level);
    });

    const bar = row.querySelector(".progress-bar");
    bar.style.width = (level / 3) * 100 + "%";           // 33% / 66% / 100%
    bar.className = "progress-bar " + RATE_COLORS[level];

    row.querySelector(".trust-label").textContent = RATINGS[level].label;
}

// Friend rating: 1 = Stupid, 2 = Cool, 3 = Trustworthy
function rateFriend(button, level) {
    const row = button.closest(".friend-row");
    const name = row.dataset.name;

    paintRating(row, level);

    // save the rating, so it stays after reload
    const ratings = readStore(RATINGS_KEY, {});
    ratings[name] = level;
    writeStore(RATINGS_KEY, ratings);

    showMessage("You rated " + name + " as " + RATINGS[level].label, "success");

    // the rated friend moves to the end of the messages panel, with the emoji
    updateInbox(name, { emoji: RATINGS[level].emoji });
}


/* ---------- Friend requests and suggestions ---------- */

function renderProfileRequests() {
    const list = loadRequests();
    document.getElementById("profileRequests").innerHTML = list.length === 0
        ? `<p class="text-secondary mt-3 mb-0">No new requests</p>`
        : list.map(r => `
            <div class="d-flex align-items-center mt-3">
                ${bust(r.name, "sm")}
                <div class="ms-2 flex-grow-1"><strong>${esc(r.name)}</strong>
                    <small class="d-block text-secondary">${r.mutual} mutual friend${r.mutual === 1 ? "" : "s"}</small></div>
                <button class="btn btn-sm btn-outline-success" onclick="acceptProfileRequest('${r.name}')"><i class="bi bi-check-lg"></i></button>
            </div>`).join("");
}

// Accept a request: the person becomes a friend and leaves the request list
function acceptProfileRequest(name) {
    const requests = loadRequests();
    const req = requests.find(r => r.name === name);

    if (!req) {
        showMessage("This request is no longer there.", "warning");
        return;
    }

    const friends = loadFriends();
    friends.push({ name: req.name, seen: Date.now(), mutual: req.mutual });
    saveFriends(friends);
    saveRequests(requests.filter(r => r.name !== name));

    renderProfileRequests();
    renderProfileFriends();
    renderProfileSuggestions();
    updateNotifications();
    showMessage(name + " is now your friend 🎉", "success");
}

function renderProfileSuggestions() {
    const invited = loadInvited();
    const people = SUGGESTIONS.filter(n => !isFriend(n));

    document.getElementById("profileSuggestions").innerHTML = people.length === 0
        ? `<p class="text-secondary mt-3 mb-0">No suggestions right now</p>`
        : people.map(n => `
            <div class="d-flex align-items-center mt-3">
                ${bust(n, "sm")}
                <div class="ms-2 flex-grow-1"><strong>${esc(n)}</strong></div>
                ${invited.includes(n)
                    ? `<button class="btn btn-sm btn-outline-info" disabled>Invited ✔</button>`
                    : `<button class="btn btn-sm btn-outline-info" onclick="sendProfileInvite(this, '${n}')">Invite</button>`}
            </div>`).join("");
}

function sendProfileInvite(button, name) {
    if (tryInvite(name)) markInvited(button);
}


/* ---------- Start the profile page ---------- */

paintProfilePic();
renderProfileFriends();
renderProfileRequests();
renderProfileSuggestions();
updateNotifications();
