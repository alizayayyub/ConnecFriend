/* =========================================================
   people.js - the drawn people (advanced cartoon style)
   - index.html   : a scene under the badges
   - home.html    : all messages from friends (right side)
   - messages.html: member pictures + "invite more" stage
   ========================================================= */

// g = m/f, skin/shirt/hair = colour number, acc = accessory
const PEOPLE = {
    "Alizay Ayyub":   { g: "f", skin: 1, shirt: 2, hair: 0, acc: "bow" },
    "Sarah Khan":     { g: "f", skin: 0, shirt: 1, hair: 0, acc: "bow" },
    "Hassan Ali":     { g: "m", skin: 1, shirt: 0, hair: 1, acc: "glasses" },
    "Noor Fatima":    { g: "f", skin: 2, shirt: 3, hair: 2, acc: "none" },
    "Muhammad Hamza": { g: "m", skin: 3, shirt: 4, hair: 0, acc: "cap" },
    "Ayesha Malik":   { g: "f", skin: 1, shirt: 5, hair: 1, acc: "headphones" },
    "Zainab Raza":    { g: "f", skin: 0, shirt: 2, hair: 3, acc: "bow" },
    "Bilal Ahmed":    { g: "m", skin: 2, shirt: 1, hair: 2, acc: "headphones" },
    "Maryam Sheikh":  { g: "f", skin: 3, shirt: 0, hair: 0, acc: "glasses" },
    "Hira Saeed":     { g: "f", skin: 1, shirt: 4, hair: 1, acc: "none" },
    "Daniyal Shah":   { g: "m", skin: 0, shirt: 3, hair: 3, acc: "cap" }
};

// friend ratings (the emoji shown above the person in the bottom panel)
const RATINGS = {
    1: { label: "Stupid",      emoji: "🤪" },
    2: { label: "Cool",        emoji: "😎" },
    3: { label: "Trustworthy", emoji: "🛡️" }
};

// colours for the drawn people
const SKIN  = ["#f6d5b8", "#e0a97d", "#b87a4b", "#7a4a2b"];
const SHIRT = ["#38bdf8", "#f472b6", "#facc15", "#4ade80", "#a78bfa", "#fb7185"];
const HAIR  = ["#1e1b4b", "#5b2a0e", "#0f172a", "#b45309"];

// arm positions for each action: [elbowX, elbowY, handX, handY]
const POSES = {
    wait:   { L: [34, 104, 52, 110], R: [86, 104, 68, 110] },                    // hands together
    juice:  { L: [34, 104, 30, 132], R: [88, 100, 76, 62],  prop: "juice" },     // sipping juice
    phone:  { L: [34, 104, 52, 96],  R: [86, 104, 68, 96],  prop: "phone" },     // texting
    wave:   { L: [34, 104, 28, 130], R: [90, 60, 104, 28] },                     // waving hello
    dance:  { L: [32, 60, 16, 30],   R: [88, 60, 104, 30] },                     // dancing
    cheer:  { L: [32, 58, 20, 26],   R: [88, 58, 100, 26], prop: "confetti" },   // cheering
    read:   { L: [34, 106, 46, 108], R: [86, 106, 74, 108], prop: "book" },      // reading
    thumbs: { L: [34, 104, 28, 130], R: [88, 100, 94, 80], prop: "thumb" },      // thumbs up
    coffee: { L: [34, 104, 54, 110], R: [86, 104, 66, 96], prop: "coffee" },     // coffee break
    selfie: { L: [34, 104, 40, 130], R: [88, 62, 106, 34], prop: "selfie" }      // taking a selfie
};

// what each action says, under the person
const CAPTION = {
    wait: "waiting ⏳", juice: "sipping juice 🧃", phone: "texting 📱", wave: "waving 👋",
    dance: "dancing 💃", cheer: "cheering 🎉", read: "reading 📖", thumbs: "thumbs up 👍",
    coffee: "coffee break ☕", selfie: "taking a selfie 🤳"
};

// make a colour a bit darker (used for shading)
function darken(hex, amount) {
    const n = parseInt(hex.slice(1), 16);
    const r = Math.round(((n >> 16) & 255) * (1 - amount));
    const g = Math.round(((n >> 8) & 255) * (1 - amount));
    const b = Math.round((n & 255) * (1 - amount));
    return `rgb(${r},${g},${b})`;
}

// draw one person as an SVG: man or woman, with an action and accessory
function figure(p, pose, view) {
    p = p || PEOPLE["Alizay Ayyub"];           // safety: unknown name -> my drawing
    const P = POSES[pose] || POSES.wait;
    const skin = SKIN[p.skin], skinShade = darken(SKIN[p.skin], 0.14);
    const shirt = SHIRT[p.shirt], shirtShade = darken(SHIRT[p.shirt], 0.22);
    const hair = HAIR[p.hair];
    const girl = p.g === "f";
    const ink = "#1e293b";
    const spread = pose === "dance" || pose === "cheer";        // legs apart
    const happy = ["dance", "cheer", "wave", "selfie"].includes(pose);
    const fl = spread ? 38 : 50, fr = spread ? 82 : 70;         // foot positions

    const shoe = x => `<rect x="${x - 11}" y="184" width="22" height="9" rx="4.5" fill="#0f172a"/>`
                    + `<rect x="${x - 7}" y="186" width="9" height="2.5" rx="1.2" fill="#64748b"/>`;
    const arm = (sx, a) => `
        <path d="M${sx} 78 L${a[0]} ${a[1]}" stroke="${shirt}" stroke-width="12" stroke-linecap="round"/>
        <path d="M${a[0]} ${a[1]} L${a[2]} ${a[3]}" stroke="${skin}" stroke-width="9" stroke-linecap="round"/>`;
    const hand = a => `<circle cx="${a[2]}" cy="${a[3]}" r="6.5" fill="${skin}"/>`;

    let s = `<svg class="person-svg" viewBox="${view || "0 0 120 200"}" xmlns="http://www.w3.org/2000/svg">`;

    // 1. long hair behind the body (girls)
    if (girl) s += `<path d="M41 40 Q39 13 60 13 Q81 13 79 40 L85 112 Q60 124 35 112 Z" fill="${hair}"/>`;

    // 2. legs and shoes
    s += girl
        ? `<path d="M52 146 L${fl} 186 M68 146 L${fr} 186" stroke="${skin}" stroke-width="9" stroke-linecap="round"/>`
        : `<path d="M52 124 L${fl} 184 M68 124 L${fr} 184" stroke="#334155" stroke-width="15" stroke-linecap="round"/>`;
    s += shoe(fl) + shoe(fr);

    // 3. neck
    s += `<rect x="54" y="48" width="12" height="20" rx="4" fill="${skinShade}"/>`;

    // 4. body: dress for girls, shirt with belt for boys
    if (girl) {
        s += `<path d="M42 72 Q60 66 78 72 L93 150 Q60 158 27 150 Z" fill="${shirt}"/>`;
        s += `<path d="M66 74 L78 72 L93 150 L80 152 Z" fill="${shirtShade}" opacity=".35"/>`;
        s += `<path d="M38 96 Q60 102 82 96 L83 102 Q60 108 37 102 Z" fill="${shirtShade}"/>`;
    } else {
        s += `<path d="M40 78 Q40 70 49 70 L71 70 Q80 70 80 78 L80 124 Q60 128 40 124 Z" fill="${shirt}"/>`;
        s += `<path d="M69 71 L80 71 L80 124 L70 124 Z" fill="${shirtShade}" opacity=".35"/>`;
        s += `<rect x="40" y="118" width="40" height="8" rx="3" fill="${ink}"/>`;
        s += `<rect x="56" y="119" width="8" height="6" rx="1.5" fill="#fbbf24"/>`;
    }
    // neckline (skin showing)
    s += girl
        ? `<path d="M50 72 Q60 88 70 72 Z" fill="${skin}"/>`
        : `<path d="M52 70 L60 84 L68 70 Z" fill="${skin}"/>`;

    // 5. arms (sleeve + forearm)
    s += arm(40, P.L) + arm(80, P.R);

    // 6. ears and head, with a little shade under the jaw
    s += `<circle cx="43" cy="42" r="3.6" fill="${skin}"/><circle cx="77" cy="42" r="3.6" fill="${skin}"/>`;
    s += `<ellipse cx="60" cy="40" rx="17" ry="18" fill="${skin}"/>`;
    s += `<path d="M45 48 Q60 62 75 48 Q70 57 60 57.5 Q50 57 45 48 Z" fill="${skinShade}" opacity=".3"/>`;

    // 7. hair in front
    if (girl) {
        s += `<path d="M41 42 Q36 66 40 86 L47 86 Q44 64 46 42 Z" fill="${hair}"/>`;
        s += `<path d="M79 42 Q84 66 80 86 L73 86 Q76 64 74 42 Z" fill="${hair}"/>`;
        s += `<path d="M41 42 Q38 14 60 14 Q82 14 79 42 Q75 27 63 25 Q52 29 45 38 Q43 40 41 42 Z" fill="${hair}"/>`;
    } else {
        s += `<path d="M41 40 Q38 14 60 14 Q82 14 79 40 Q78 30 70 27 Q58 33 44 27 Q41 31 41 40 Z" fill="${hair}"/>`;
        s += `<path d="M46 25 Q60 19 74 25" stroke="rgba(255,255,255,.25)" stroke-width="2" fill="none" stroke-linecap="round"/>`;
    }

    // 8. face: eyebrows, eyes, nose, mouth, blush
    s += `<path d="M48 35 Q53 32.5 57 35" stroke="${hair}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`
       + `<path d="M63 35 Q67 32.5 72 35" stroke="${hair}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`;
    if (happy) {
        s += `<path d="M48.5 41 Q53 36.5 57.5 41" stroke="${ink}" stroke-width="2.2" fill="none" stroke-linecap="round"/>`
           + `<path d="M62.5 41 Q67 36.5 71.5 41" stroke="${ink}" stroke-width="2.2" fill="none" stroke-linecap="round"/>`;
    } else {
        s += `<ellipse cx="53" cy="41" rx="3.4" ry="3.9" fill="#fff"/><ellipse cx="67" cy="41" rx="3.4" ry="3.9" fill="#fff"/>`
           + `<circle cx="53.6" cy="41.6" r="2.2" fill="${ink}"/><circle cx="67.6" cy="41.6" r="2.2" fill="${ink}"/>`
           + `<circle cx="54.4" cy="40.6" r=".8" fill="#fff"/><circle cx="68.4" cy="40.6" r=".8" fill="#fff"/>`;
    }
    s += `<path d="M60 43 Q61.5 46 59.5 47" stroke="${skinShade}" stroke-width="1.5" fill="none" stroke-linecap="round"/>`;
    s += happy
        ? `<path d="M52.5 50 Q60 60 67.5 50 Z" fill="#9f1239"/><path d="M55 52.5 Q60 56 65 52.5 Q60 54 55 52.5 Z" fill="#fb7185"/>`
        : `<path d="M54 50.5 Q60 55.5 66 50.5" stroke="${ink}" stroke-width="2" fill="none" stroke-linecap="round"/>`;
    s += `<circle cx="47.5" cy="48" r="3.2" fill="#fb7185" opacity=".4"/><circle cx="72.5" cy="48" r="3.2" fill="#fb7185" opacity=".4"/>`;

    // 9. fun accessories
    if (p.acc === "glasses") {
        s += `<g fill="rgba(186,230,253,.25)" stroke="${ink}" stroke-width="1.8"><rect x="46" y="36" width="12" height="10" rx="4"/><rect x="62" y="36" width="12" height="10" rx="4"/></g>`
           + `<path d="M58 40 Q60 38 62 40" stroke="${ink}" stroke-width="1.8" fill="none"/>`;
    }
    if (p.acc === "cap") {
        s += `<path d="M41 30 Q60 2 79 30 Z" fill="${shirt}"/>`
           + `<path d="M33 31 Q60 22 87 31 Q85 37 60 37 Q35 37 33 31 Z" fill="${shirtShade}"/>`;
    }
    if (p.acc === "headphones") {
        s += `<path d="M39 44 Q38 14 60 14 Q82 14 81 44" fill="none" stroke="${ink}" stroke-width="4"/>`
           + `<rect x="33" y="38" width="9" height="15" rx="4.5" fill="${ink}"/><rect x="78" y="38" width="9" height="15" rx="4.5" fill="${ink}"/>`
           + `<rect x="35" y="41" width="3" height="5" rx="1.5" fill="#38bdf8"/><rect x="82" y="41" width="3" height="5" rx="1.5" fill="#38bdf8"/>`;
    }
    if (p.acc === "bow") {
        s += `<path d="M74 20 L88 11 L88 29 Z M74 20 L60 11 L60 29 Z" fill="#f472b6"/><circle cx="74" cy="20" r="2.6" fill="#be185d"/>`;
    }

    // 10. props for the action (drawn before the hands)
    if (pose === "juice") {
        s += `<path d="M79 40 L87 28" stroke="#f43f5e" stroke-width="2.6" stroke-linecap="round"/>`
           + `<path d="M68 42 H80 L78 64 H70 Z" fill="#fb923c"/>`
           + `<path d="M69.5 46 H78.5 L77.6 58 H70.4 Z" fill="#fdba74"/>`
           + `<path d="M68 42 H80 L79.6 45 H68.4 Z" fill="#fef3c7"/>`;
    }
    if (pose === "phone") {
        s += `<rect x="46" y="82" width="28" height="36" rx="5.5" fill="${ink}"/>`
           + `<rect x="50" y="87" width="20" height="26" rx="2.5" fill="#38bdf8"/>`
           + `<path d="M52 92 H68 M52 97 H64" stroke="#e0f2fe" stroke-width="1.6" stroke-linecap="round"/>`;
    }
    if (pose === "read") {
        s += `<path d="M60 96 Q50 89 38 93 L38 111 Q50 107 60 113 Z" fill="#f8fafc"/>`
           + `<path d="M60 96 Q70 89 82 93 L82 111 Q70 107 60 113 Z" fill="#e2e8f0"/>`
           + `<path d="M60 96 V113" stroke="#94a3b8" stroke-width="1.5"/>`;
    }
    if (pose === "thumbs") {
        s += `<rect x="91" y="64" width="6.5" height="15" rx="3.2" fill="${skin}"/>`;
    }
    if (pose === "coffee") {
        s += `<rect x="56" y="90" width="18" height="18" rx="4" fill="#fef3c7"/>`
           + `<rect x="56" y="90" width="18" height="5" rx="2" fill="#92400e"/>`
           + `<path d="M74 96 Q81 96 80 102 Q79 106 73 105" stroke="#fef3c7" stroke-width="3" fill="none"/>`
           + `<path d="M61 84 Q58 79 62 75 Q66 71 63 67 M68 84 Q65 79 69 75 Q73 71 70 67" stroke="#cbd5e1" stroke-width="1.8" fill="none" stroke-linecap="round"/>`;
    }
    if (pose === "selfie") {
        s += `<rect x="99" y="18" width="14" height="24" rx="3.5" fill="${ink}"/>`
           + `<rect x="102" y="23" width="8" height="14" rx="1.5" fill="#38bdf8"/>`
           + `<circle cx="106" cy="20" r="1" fill="#64748b"/>`;
    }
    if (pose === "cheer") {
        const bits = [[10, 26, "#facc15", 20], [104, 60, "#f472b6", -25], [14, 82, "#4ade80", 40],
                      [102, 10, "#38bdf8", 15], [6, 54, "#a78bfa", -10], [110, 96, "#fb7185", 30]];
        s += bits.map(b => `<rect x="${b[0]}" y="${b[1]}" width="4" height="8" rx="1.5" fill="${b[2]}" transform="rotate(${b[3]} ${b[0]} ${b[1]})"/>`).join("");
    }

    // 11. hands last, so they sit on top of the props
    s += hand(P.L) + hand(P.R);
    return s + `</svg>`;
}

// round head-and-shoulders picture (feed, member list, chat)
function bust(name, size) {
    const extra = size === "sm" ? " bust-sm" : size === "lg" ? " bust-lg" : "";
    return `<div class="bust${extra}">${figure(PEOPLE[name], "wait", "18 6 84 84")}</div>`;
}

// first 4 words, time text, safe text
function firstWords(text, count) {
    if (!text) return "No message yet";
    const words = text.trim().split(/\s+/);
    return words.slice(0, count).join(" ") + (words.length > count ? "..." : "");
}

function timeAgo(timestamp) {
    const minutes = Math.floor((Date.now() - timestamp) / 60000);
    if (minutes < 1) return "just now";
    if (minutes < 60) return minutes + " min ago";
    if (minutes < 1440) return Math.floor(minutes / 60) + " h ago";
    return Math.floor(minutes / 1440) + " d ago";
}

function esc(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

/* ---------- Messages from my people (bottom panel on home) ---------- */

const ago = minutes => Date.now() - minutes * 60000;

// the starting list: people who sent me a message
const SEED_INBOX = [
    { name: "Ayesha Malik",   pose: "dance", msg: "Weekend plan: hiking and chai, are you in?",              at: ago(1500), emoji: null },
    { name: "Muhammad Hamza", pose: "wave",  msg: "Bro the cricket match tonight was insane",                  at: ago(240),  emoji: null },
    { name: "Noor Fatima",    pose: "wait",  msg: "Save me a seat in the library, I am running late",         at: ago(60),   emoji: null },
    { name: "Hassan Ali",     pose: "juice", msg: "Did you finish the assignment? I am stuck on question 3",  at: ago(35),   emoji: null },
    { name: "Sarah Khan",     pose: "phone", msg: "Hi! How are you? Let's meet at the library tomorrow",      at: ago(10),   emoji: null }
];

// saved in this browser, so the panel stays the same after reload
function loadInbox() {
    try {
        const saved = JSON.parse(localStorage.getItem("cf_inbox"));
        if (Array.isArray(saved)) return saved;
    } catch (e) { /* broken data -> start fresh */ }
    return SEED_INBOX.map(item => ({ ...item }));
}

function saveInbox(list) {
    try {
        localStorage.setItem("cf_inbox", JSON.stringify(list));
    } catch (e) {
        alert("Could not save (browser storage is full).");
    }
}

// change one person's entry and move it to the end (= latest action)
function updateInbox(name, changes) {
    const list = loadInbox();
    const old = list.find(x => x.name === name) || {
        name: name,
        pose: ["wait", "juice", "phone", "wave", "dance"][Math.floor(Math.random() * 5)],
        msg: "",
        emoji: null
    };
    const rest = list.filter(x => x.name !== name);
    saveInbox([...rest, { ...old, ...changes, at: Date.now() }]);
    renderMessages();
}

// list of messages from my friends (home page): latest action at the bottom
function renderMessages() {
    document.querySelectorAll("[data-messages]").forEach(box => {
        const items = loadInbox().slice().sort((a, b) => a.at - b.at);
        box.innerHTML = items.length === 0
            ? `<p class="text-secondary mb-0">No messages yet</p>`
            : items.map(it => `
                <a class="msg-row" href="messages.html?with=${encodeURIComponent(it.name)}">
                    <div class="msg-fig">
                        <div class="mood-emoji">${it.emoji || ""}</div>
                        ${figure(PEOPLE[it.name], it.pose)}
                    </div>
                    <div class="msg-body">
                        <div class="person-meta"><strong>${esc(it.name)}</strong> <small>· ${timeAgo(it.at)}</small></div>
                        <div class="bubble-msg">${esc(firstWords(it.msg, 4))}</div>
                    </div>
                </a>`).join("");
    });
}

/* ---------- Scenes: groups of people with speech bubbles ---------- */

const SCENES = {
    login: [
        { name: "Sarah Khan",     pose: "phone",  say: "Hi! 👋" },
        { name: "Hassan Ali",     pose: "read",   say: "Chapter 3 is 🔥" },
        { name: "Ayesha Malik",   pose: "cheer",  say: "New friends!" },
        { name: "Muhammad Hamza", pose: "thumbs", say: "Nice post!" }
    ],
    invite: [
        { name: "Bilal Ahmed",    pose: "selfie" },
        { name: "Daniyal Shah",   pose: "cheer" }
    ]
};

function renderScenes() {
    document.querySelectorAll("[data-scene]").forEach(box => {
        const list = SCENES[box.dataset.scene] || [];
        box.innerHTML = list.map((it, i) => `
            <div class="scene-person" style="animation-delay: ${i * 0.3}s">
                ${it.say ? `<div class="speech">${esc(it.say)}</div>` : ""}
                ${figure(PEOPLE[it.name], it.pose)}
                <small>${it.name.split(" ")[0]} · ${CAPTION[it.pose]}</small>
            </div>`).join("");
    });
}

// member pictures in the messages list: <div data-bust="Name"></div>
function renderBusts() {
    document.querySelectorAll("[data-bust]").forEach(el => {
        el.innerHTML = figure(PEOPLE[el.dataset.bust], "wait", "18 6 84 84");
    });
}

renderScenes();
renderBusts();
renderMessages();
