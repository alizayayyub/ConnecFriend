/* login.js - login page */

document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();                                   // do not reload the page

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const error = document.getElementById("error");

    if (username === "" || password === "") {
        error.textContent = "Please enter both username and password.";
        error.classList.remove("d-none");
        return;
    }

    if (username === "alizay" && password === "12345") {
        localStorage.setItem("loggedIn", username);
        window.location.href = "home.html";
    } else {
        error.textContent = "Wrong username or password.";
        error.classList.remove("d-none");
    }
});
