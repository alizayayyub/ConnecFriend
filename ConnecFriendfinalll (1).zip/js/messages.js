/* messages.js - only for the messages page */

// Members who are not my friends (they can still get private messages)
const OTHER_MEMBERS = ["Maryam Sheikh", "Bilal Ahmed", "Hira Saeed"];

// The first chats. After the first message, all chats are saved in this browser.
// "me" = sent by me, "them" = received.
const SEED_CHATS = {
    "Sarah Khan": [["them", "Hi! How are you?"], ["me", "I am good. How about you?"], ["them", "I am doing great!"]],
    "Hassan Ali": [["them", "Did you finish the assignment?"]]
};

// Replies that other people send back
const REPLIES = [
    "Got it 👍", "Sure, let's talk later!", "Haha, nice 😂", "Thanks for telling me!",
    "I will reply in detail soon", "Sounds good to me 🙌", "Okay, see you then 😊"
];

let currentMember = "";     // the chat that is open
let typingFor = null;       // the person who is typing right now


/* ---------- Saving chats ---------- */

function loadChats() {
    const saved = readStore("cf_chats", null);
    return saved && typeof saved === "object" ? saved : JSON.parse(JSON.stringify(SEED_CHATS));
}

function getChat(name) {
    const chats = loadChats();
    return Array.isArray(chats[name]) ? chats[name] : [];
}

function saveChat(name, list) {
    const chats = loadChats();
    chats[name] = list;
    return writeStore("cf_chats", chats);
}


/* ---------- Members list: friends first, then other members ---------- */

function renderMembers() {
    const friends = friendsByLogin().map(f => ({ name: f.name, label: "Friend" }));
    const others = OTHER_MEMBERS.map(n => ({ name: n, label: "Member" }));

    document.getElementById("memberList").innerHTML = friends.concat(others).map(m => `
        <button class="member-button" data-member="${esc(m.name)}" onclick="selectMember('${m.name}')">
            ${bust(m.name, "sm")}
            <div>
                <strong>${esc(m.name)}</strong>
                <small class="d-block text-secondary">${m.label}</small>
            </div>
        </button>`).join("");
}

// Open the chat with one person (click on a member, or a link)
function selectMember(name) {
    currentMember = name;
    document.getElementById("chatName").textContent = name;

    // highlight the selected member
    document.querySelectorAll(".member-button").forEach(btn => {
        btn.classList.toggle("active", btn.dataset.member === name);
    });

    showChat();
}


/* ---------- Chat ---------- */

// Draw all messages of the open chat
function showChat() {
    const area = document.getElementById("chatArea");
    const messages = getChat(currentMember);
    area.innerHTML = "";

    if (messages.length === 0 && typingFor !== currentMember) {
        area.innerHTML = '<p class="text-secondary text-center mt-5">No messages yet. Say hello 👋</p>';
        return;
    }

    messages.forEach(m => {
        const div = document.createElement("div");
        div.className = m[0] === "me" ? "sent-message" : "received-message";
        div.textContent = m[1];                           // textContent keeps the text safe
        area.appendChild(div);
    });

    if (typingFor === currentMember) {
        const dots = document.createElement("div");
        dots.className = "received-message typing";
        dots.textContent = "typing…";
        area.appendChild(dots);
    }

    area.scrollTop = area.scrollHeight;                   // scroll to newest message
}

function sendMessage() {
    const input = document.getElementById("messageInput");
    const text = input.value.trim();

    // Error handling
    if (text === "") {
        showMessage("Please write a message first.", "warning");
        return;
    }
    if (text.length > 300) {
        showMessage("Message is too long (max 300 letters).", "warning");
        return;
    }

    const name = currentMember;
    const list = getChat(name);
    list.push(["me", text]);
    if (!saveChat(name, list)) return;

    input.value = "";
    showChat();
    replyLater(name);
}

// The other person "types" for a moment, then replies
function replyLater(name) {
    typingFor = name;
    showChat();

    setTimeout(function () {
        typingFor = null;
        const reply = REPLIES[Math.floor(Math.random() * REPLIES.length)];

        const list = getChat(name);
        list.push(["them", reply]);
        saveChat(name, list);

        // a friend's latest message also shows in the home page panel
        if (isFriend(name)) {
            updateInbox(name, { msg: reply });
        }

        if (name === currentMember) showChat();
    }, 1500);
}

// Smart reply buttons: put ready-made text in the box
function quickReply(text) {
    document.getElementById("messageInput").value = text;
}


/* ---------- Start the messages page ---------- */

renderMembers();

// Open the chat from a link like messages.html?with=Muhammad%20Hamza, otherwise Sarah (or the first member)
const asked = new URLSearchParams(window.location.search).get("with");
const names = Array.from(document.querySelectorAll(".member-button")).map(b => b.dataset.member);
const first = names.includes("Sarah Khan") ? "Sarah Khan" : names[0];
selectMember(names.includes(asked) ? asked : first);
