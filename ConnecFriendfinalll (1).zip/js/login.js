/* login.js - only for the login page */

const loginForm = document.getElementById("loginForm");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const errorMessage = document.getElementById("errorMessage");
const errorText = document.getElementById("errorText");

loginForm.addEventListener("submit", function (event) {
    event.preventDefault();               // stop page from reloading

    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    // Empty field validation
    if (username === "" || password === "") {
        showError("Please enter both username and password.");
        return;
    }

    // Demo credentials
    if (username === "alizay" && password === "12345") {
        localStorage.setItem("loggedInUser", username);
        window.location.href = "home.html";
    } else {
        showError("Incorrect username or password.");
    }
});

function showError(message) {
    errorText.textContent = message;
    errorMessage.classList.remove("d-none");
}

// Show / hide password
function togglePassword() {
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
    } else {
        passwordInput.type = "password";
    }
}
