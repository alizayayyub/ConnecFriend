/* home.js - only for the home page */

// (ignoreList and the invite helpers are now in js/common.js, shared with the Profile page)

// Names shown on the mood badge
const moodNames = {
    happy: "😄 Happy",
    focused: "🎯 Focused",
    excited: "🔥 Excited",
    chill: "😎 Chill"
};

const POSTS_KEY = "cf_posts";      // my own shared news
const REACT_KEY = "cf_reacts";     // likes and dislikes of every post


/* ================= LEFT: FRIENDS AND REQUESTS ================= */

// Friend list, newest login first. "Online" = logged in within the last hour.
function renderFriendList() {
    document.getElementById("friendList").innerHTML = friendsByLogin().map(f => {
        const online = (Date.now() - f.seen) < 60 * 60000;
        return `
            <div class="d-flex align-items-center mt-3">
                ${bust(f.name, "sm")}
                <div class="ms-2"><strong>${esc(f.name)}</strong>
                    <small class="d-block text-secondary"><span class="online-dot ${online ? "" : "offline"}"></span>${timeAgo(f.seen)}</small></div>
            </div>`;
    }).join("");
}

function renderRequests() {
    const list = loadRequests();
    document.getElementById("requestList").innerHTML = list.length === 0
        ? `<p class="text-secondary mt-3 mb-0">No new requests</p>`
        : list.map(r => `
            <div class="d-flex align-items-center mt-3">
                ${bust(r.name, "sm")}
                <div class="ms-2 flex-grow-1"><strong>${esc(r.name)}</strong>
                    <small class="d-block text-secondary">${r.mutual} mutual friend${r.mutual === 1 ? "" : "s"}</small></div>
                <button class="btn btn-sm btn-outline-success" onclick="acceptRequest('${r.name}')"><i class="bi bi-check-lg"></i></button>
            </div>`).join("");
}

// Accept a request: the person becomes a friend and leaves the request list
function acceptRequest(name) {
    const requests = loadRequests();
    const req = requests.find(r => r.name === name);

    // Error handling: the request must still be there
    if (!req) {
        showMessage("This request is no longer there.", "warning");
        return;
    }

    const friends = loadFriends();
    friends.push({ name: req.name, seen: Date.now(), mutual: req.mutual });
    saveFriends(friends);
    saveRequests(requests.filter(r => r.name !== name));

    renderFriendList();
    renderRequests();
    renderFriendChoices();
    updateNotifications();
    showMessage(name + " is now your friend 🎉", "success");
}


/* ================= INVITE A FRIEND ================= */

function sendInvite(button, name) {
    if (tryInvite(name)) markInvited(button);     // checks (ignored / already friend) are inside tryInvite
}

// After reload: people I already invited keep showing "Invited ✔"
function restoreInvited() {
    const invited = loadInvited();
    document.querySelectorAll("button[onclick^='sendInvite']").forEach(btn => {
        const name = btn.closest(".d-flex").querySelector("strong").textContent;
        if (invited.includes(name)) markInvited(btn);
    });
}


/* ================= SHARE NEWS ================= */

// Show the friend checkboxes only when "Some friends" is selected
function showFriendChoices() {
    const box = document.getElementById("friendChoices");

    if (document.getElementById("someFriends").checked) {
        box.classList.remove("d-none");
    } else {
        box.classList.add("d-none");
    }
}

// One checkbox for each friend (so accepted friends appear too)
function renderFriendChoices() {
    document.getElementById("friendChoices").innerHTML = friendsByLogin().map((f, i) => `
        <div class="form-check form-check-inline">
            <input class="form-check-input friend-check" type="checkbox" id="c${i}" value="${esc(f.name)}">
            <label class="form-check-label" for="c${i}">${esc(f.name.split(" ")[0])}</label>
        </div>`).join("");
}

// Saved posts of mine (a list, oldest first)
function loadPosts() {
    const saved = readStore(POSTS_KEY, []);
    return Array.isArray(saved) ? saved : [];
}

// One card for one of my posts
function postHTML(p) {
    return `
        <div class="card-neon mb-4 mood-${p.mood} own-post" data-post="${p.id}">
            <div class="d-flex align-items-center">
                ${myPicture()}
                <div class="ms-3">
                    <h6 class="mb-0">You <span class="badge text-bg-dark">${moodNames[p.mood]}</span></h6>
                    <small class="text-secondary">${timeAgo(p.at)} · shared with ${esc(p.audience)}</small>
                </div>
            </div>
            <p class="mt-3">${esc(p.text)}</p>
            <div>
                <button class="btn btn-sm btn-outline-info btn-like" onclick="likePost('${p.id}')">
                    <i class="bi bi-hand-thumbs-up"></i> Like <span class="like-count">0</span></button>
                <button class="btn btn-sm btn-outline-danger btn-dislike" onclick="dislikePost('${p.id}')">
                    <i class="bi bi-hand-thumbs-down"></i> Dislike <span class="dislike-count">0</span></button>
            </div>
        </div>`;
}

// Put my saved posts at the top of the feed (newest first)
function renderOwnPosts() {
    const posts = loadPosts();
    document.getElementById("feed").insertAdjacentHTML("afterbegin", posts.slice().reverse().map(p => postHTML(p)).join(""));
}

function sharePost() {
    const text = document.getElementById("postText").value.trim();
    const mood = document.getElementById("moodSelect").value;
    const toAll = document.getElementById("allFriends").checked;
    let audience = "All friends";

    // Error handling
    if (text === "") {
        showMessage("Please write something before sharing.", "warning");
        return;
    }
    if (text.length > 280) {
        showMessage("Please keep it under 280 letters.", "warning");
        return;
    }

    if (toAll === false) {
        const chosen = Array.from(document.querySelectorAll(".friend-check:checked"));

        if (chosen.length === 0) {
            showMessage("Please select at least one friend.", "warning");
            return;
        }
        audience = chosen.map(c => c.value).join(", ");     // names of the chosen friends
    }

    // Save the post, so it is still there after reload
    const post = { id: "own" + Date.now(), text: text, mood: mood, audience: audience, at: Date.now() };
    const posts = loadPosts();
    posts.push(post);
    if (!writeStore(POSTS_KEY, posts)) return;

    // Put the new post at the top of the feed
    document.getElementById("feed").insertAdjacentHTML("afterbegin", postHTML(post));

    // Clear the form
    document.getElementById("postText").value = "";
    showMessage("Your news has been shared ✨", "success");
}


/* ================= LIKE / DISLIKE (change or remove any time) ================= */

// Start numbers of a post: the numbers written in the HTML (or 0)
function startNumbers(card) {
    return {
        likes: Number(card.querySelector(".like-count").textContent),
        dislikes: Number(card.querySelector(".dislike-count").textContent),
        mine: null                       // my choice: "like", "dislike" or null
    };
}

function reactPost(postId, kind) {
    const card = document.querySelector(`[data-post="${postId}"]`);
    if (!card) return;

    const all = readStore(REACT_KEY, {});
    const state = all[postId] || startNumbers(card);
    let text;

    if (state.mine === kind) {
        // same button again: take my reaction back
        if (kind === "like") state.likes = Math.max(0, state.likes - 1);
        else state.dislikes = Math.max(0, state.dislikes - 1);
        state.mine = null;
        text = kind === "like" ? "Like removed" : "Dislike removed";
    } else {
        // the other button was chosen before: switch from it
        if (state.mine === "like") state.likes = Math.max(0, state.likes - 1);
        if (state.mine === "dislike") state.dislikes = Math.max(0, state.dislikes - 1);

        if (kind === "like") state.likes++;
        else state.dislikes++;
        state.mine = kind;
        text = kind === "like" ? "You liked this post 👍" : "You disliked this post 👎";
    }

    all[postId] = state;
    if (writeStore(REACT_KEY, all)) {
        paintPost(postId, state);
        showMessage(text, "success");
    }
}

function likePost(postId) {
    reactPost(postId, "like");
}

function dislikePost(postId) {
    reactPost(postId, "dislike");
}

// Show the counts and the chosen button of one post
function paintPost(postId, state) {
    const card = document.querySelector(`[data-post="${postId}"]`);
    if (!card) return;

    card.querySelector(".like-count").textContent = state.likes;
    card.querySelector(".dislike-count").textContent = state.dislikes;
    card.querySelector(".btn-like").classList.toggle("chosen", state.mine === "like");
    card.querySelector(".btn-dislike").classList.toggle("chosen", state.mine === "dislike");
}

// On page load: show the saved likes and dislikes
function restoreReacts() {
    const all = readStore(REACT_KEY, {});
    Object.keys(all).forEach(id => paintPost(id, all[id]));
}


/* ================= FEED: friends with the latest login first ================= */

function arrangeFeed() {
    const feed = document.getElementById("feed");
    const friends = loadFriends();
    const posts = Array.from(feed.querySelectorAll(".friend-post"));

    // login time of the friend who wrote the post
    const seenOf = name => {
        const f = friends.find(x => x.name === name);
        return f ? f.seen : 0;
    };

    // 1. show "Last login X ago" on each friend post
    posts.forEach(post => {
        post.querySelector(".last-login").textContent = "Last login " + timeAgo(seenOf(post.dataset.friend));
    });

    // 2. newest login first: move the cards to the end of the feed in that order
    posts.sort((a, b) => seenOf(b.dataset.friend) - seenOf(a.dataset.friend));
    posts.forEach(post => feed.appendChild(post));
}


/* ================= START THE HOME PAGE ================= */

renderFriendList();
renderRequests();
renderFriendChoices();
renderOwnPosts();
arrangeFeed();
restoreReacts();
restoreInvited();
updateNotifications();
