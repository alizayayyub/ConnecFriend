/* profile.js - profile picture, friend list and friend rating */

const RATING_NAMES = ["", "Stupid", "Cool", "Trustworthy"];

// ---------- Profile picture (first letter of my name) ----------
function showPicture() {
    document.getElementById("profilePic").innerHTML =
        `<span class="rounded-circle bg-maroon text-white d-inline-flex align-items-center justify-content-center display-4" style="width:120px;height:120px;">${ME[0]}</span>`;
}

// ---------- Friends with rating ----------
function showFriends() {
    const friends = friendsByLogin();
    const ratings = load("ratings", {});

    document.getElementById("friendCount").textContent = friends.length;

    document.getElementById("friendList").innerHTML = friends.map(f => {
        const r = ratings[f.name] || 0;
        return `
        <div class="d-flex align-items-center border-bottom py-2">
            ${avatar(f.name)}
            <div class="flex-grow-1">
                <strong>${safe(f.name)}</strong><br>
                <small class="text-muted">Rating: ${r ? RATING_NAMES[r] : "Not rated"}</small>
            </div>
            <button class="btn btn-sm rate-btn ${r === 1 ? "active" : ""}" title="Stupid" onclick="rate('${f.name}', 1)"><i class="bi bi-emoji-dizzy fs-5"></i></button>
            <button class="btn btn-sm rate-btn ${r === 2 ? "active" : ""}" title="Cool" onclick="rate('${f.name}', 2)"><i class="bi bi-emoji-sunglasses fs-5"></i></button>
            <button class="btn btn-sm rate-btn ${r === 3 ? "active" : ""}" title="Trustworthy" onclick="rate('${f.name}', 3)"><i class="bi bi-shield-check fs-5"></i></button>
        </div>`;
    }).join("");
}

// 1 = Stupid, 2 = Cool, 3 = Trustworthy
function rate(name, level) {
    const ratings = load("ratings", {});
    ratings[name] = level;
    save("ratings", ratings);
    showFriends();
    showAlert("You rated " + name + " as " + RATING_NAMES[level] + ".", "success");
}

// ---------- Start ----------
showPicture();
showFriends();
