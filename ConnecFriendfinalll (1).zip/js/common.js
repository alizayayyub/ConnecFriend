/* common.js - used on Home, Profile and Messages pages */

// 1. If the user did not log in, send them back to the login page
if (localStorage.getItem("loggedInUser") === null) {
    window.location.href = "index.html";
}

const ME = "Alizay Ayyub";              // the person who is logged in
const PHOTO_KEY = "cf_photo";           // my uploaded profile photo

// 2. Logout button
function logout() {
    localStorage.removeItem("loggedInUser");
    window.location.href = "index.html";
}

// 3. Show a small coloured popup message for 3 seconds
//    type can be: success, warning, danger
let msgTimer = null;
function showMessage(text, type) {
    const box = document.getElementById("msgBox");
    box.textContent = text;
    box.className = "alert alert-" + type;

    clearTimeout(msgTimer);                       // a new message gets its full 3 seconds
    msgTimer = setTimeout(function () {
        box.className = "d-none";
    }, 3000);
}

// 4. Saving in the browser (localStorage). These never crash the page.
function readStore(key, fallback) {
    try {
        const value = JSON.parse(localStorage.getItem(key));
        return value === null ? fallback : value;
    } catch (e) {
        return fallback;                          // nothing saved yet, or broken data
    }
}

function writeStore(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
    } catch (e) {
        showMessage("Could not save. Browser storage is full or blocked.", "danger");
        return false;
    }
}

// 5. Friends and friend requests
//    "login" = minutes since that friend last logged in (used only on the first visit)
const START_FRIENDS = [
    { name: "Sarah Khan",     login: 10,   mutual: 2 },
    { name: "Hassan Ali",     login: 35,   mutual: 3 },
    { name: "Noor Fatima",    login: 60,   mutual: 5 },
    { name: "Muhammad Hamza", login: 240,  mutual: 4 },
    { name: "Ayesha Malik",   login: 1440, mutual: 1 }
];

const START_REQUESTS = [
    { name: "Zainab Raza", mutual: 1 }
];

function loadFriends() {
    const saved = readStore("cf_friends", null);
    if (Array.isArray(saved)) return saved;

    // first visit: make the list and save it, so the login times stay the same
    const now = Date.now();
    const list = START_FRIENDS.map(f => ({ name: f.name, seen: now - f.login * 60000, mutual: f.mutual }));
    writeStore("cf_friends", list);
    return list;
}

function saveFriends(list) {
    return writeStore("cf_friends", list);
}

// Friends with the newest login first
function friendsByLogin() {
    return loadFriends().slice().sort((a, b) => b.seen - a.seen);
}

function isFriend(name) {
    return loadFriends().some(f => f.name === name);
}

function loadRequests() {
    const saved = readStore("cf_requests", null);
    if (Array.isArray(saved)) return saved;

    writeStore("cf_requests", START_REQUESTS);
    return START_REQUESTS.map(r => ({ ...r }));
}

function saveRequests(list) {
    return writeStore("cf_requests", list);
}

// 6. My picture: the uploaded photo, or my drawn cartoon
function myPicture() {
    const photo = readStore(PHOTO_KEY, null);
    return photo
        ? `<div class="bust bust-sm"><img class="avatar-img" src="${photo}" alt="My photo"></div>`
        : bust(ME, "sm");
}


// 7. Suggestions ("People you may know") and invites - shared by Home and Profile
const SUGGESTIONS = ["Maryam Sheikh", "Bilal Ahmed", "Hira Saeed", "Daniyal Shah"];

// People who put ME in their ignore list. I cannot invite them.
const ignoreList = ["Bilal Ahmed", "Daniyal Shah"];

const INVITED_KEY = "cf_invited";       // people I already sent a request to

function loadInvited() {
    const saved = readStore(INVITED_KEY, []);
    return Array.isArray(saved) ? saved : [];
}

// Try to send a friend request. Returns true only if the request was sent.
function tryInvite(name) {
    if (ignoreList.includes(name)) {
        showMessage(name + " has ignored you. Request cannot be sent.", "danger");
        return false;
    }
    if (isFriend(name)) {
        showMessage(name + " is already your friend.", "warning");
        return false;
    }

    const invited = loadInvited();
    if (!invited.includes(name)) {
        invited.push(name);
        if (!writeStore(INVITED_KEY, invited)) return false;
    }
    showMessage("Friend request sent to " + name, "success");
    return true;
}

function markInvited(button) {
    button.textContent = "Invited \u2714";
    button.disabled = true;
}

// 8. Notification bell in the navbar (number = new friend requests)
function addNotificationBell() {
    const container = document.querySelector(".navbar .container");
    const toggler = document.querySelector(".navbar-toggler");
    if (!container || !toggler || document.getElementById("notifLink")) return;

    // the Friend Requests card is on this page? scroll to it. Otherwise go to Home.
    const target = document.getElementById("requestsCard") ? "#requestsCard" : "home.html#requestsCard";

    const link = document.createElement("a");
    link.id = "notifLink";
    link.className = "notif-bell ms-auto ms-lg-2 me-3 me-lg-0 order-lg-last";
    link.href = target;
    link.innerHTML = '<i class="bi bi-bell-fill"></i><span id="notifCount" class="notif-count d-none">0</span>';
    container.insertBefore(link, toggler);

    updateNotifications();
}

// Count the saved requests and show the number (hidden when it is 0)
function updateNotifications() {
    const link = document.getElementById("notifLink");
    const badge = document.getElementById("notifCount");
    if (!link || !badge) return;

    const count = loadRequests().length;
    badge.textContent = count;
    badge.classList.toggle("d-none", count === 0);
    link.title = count === 0 ? "No new notifications"
        : count + " new friend request" + (count === 1 ? "" : "s");
}

addNotificationBell();
