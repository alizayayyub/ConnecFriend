/* messages.js - private messages to friends AND other members */

let current = "";          // name of the person whose chat is open

// chats are saved like this: { "Sarah Khan": ["hello", "how are you"], ... }
function getChats() {
    return load("chats", {});
}

// ---------- Member list: friends first, then other members ----------
function showMembers() {
    const friends = friendsByLogin().map(f => ({ name: f.name, label: "Friend" }));
    const others = OTHER_MEMBERS.filter(n => !getFriends().some(f => f.name === n))
                                .map(n => ({ name: n, label: "Member" }));

    document.getElementById("memberList").innerHTML = friends.concat(others).map(m => `
        <button class="list-group-item list-group-item-action d-flex align-items-center ${m.name === current ? "active" : ""}"
                onclick="openChat('${m.name}')">
            ${avatar(m.name)}
            <div>${safe(m.name)}<br><small>${m.label}</small></div>
        </button>`).join("");
}

function openChat(name) {
    current = name;
    document.getElementById("chatName").textContent = name;
    showMembers();
    showChat();
}

// ---------- Chat ----------
function showChat() {
    const messages = getChats()[current] || [];
    const area = document.getElementById("chatArea");

    if (messages.length === 0) {
        area.innerHTML = '<p class="text-muted text-center mt-5">No messages yet.</p>';
        return;
    }

    // every message I send is shown on the right with "Sent" below it
    area.innerHTML = messages.map(text => `
        <div class="text-end mb-2">
            <span class="d-inline-block bg-maroon text-white rounded px-3 py-2">${safe(text)}</span><br>
            <small class="text-muted">Sent</small>
        </div>`).join("");

    area.scrollTop = area.scrollHeight;      // scroll to the newest message
}

function sendMessage() {
    const input = document.getElementById("messageInput");
    const text = input.value.trim();

    if (current === "") {
        showAlert("Please select a member first.", "warning");
        return;
    }
    if (text === "") {
        showAlert("Please write a message first.", "warning");
        return;
    }

    const chats = getChats();
    if (!chats[current]) chats[current] = [];
    chats[current].push(text);
    save("chats", chats);

    input.value = "";
    showChat();
}

// ---------- Start ----------
showMembers();
