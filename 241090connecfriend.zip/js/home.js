/* home.js - friends list, news feed, share, like/dislike, invite */

// ---------- Posts (saved in localStorage) ----------
// each post: { id, author, text, likes, dislikes, mine, audience, at }
// mine = my reaction: "like", "dislike" or null
function getPosts() {
    let posts = load("posts", null);
    if (posts === null) {
        posts = [
            { id: "p1", author: "Sarah Khan",     text: "Just finished my first web development project!", likes: 12, dislikes: 2, mine: null },
            { id: "p2", author: "Hassan Ali",     text: "Tip: write the HTML first, style it later.",      likes: 20, dislikes: 1, mine: null },
            { id: "p3", author: "Noor Fatima",    text: "The library is the best place to study.",         likes: 9,  dislikes: 0, mine: null },
            { id: "p4", author: "Muhammad Hamza", text: "Learning new technologies every day.",            likes: 8,  dislikes: 1, mine: null }
        ];
        save("posts", posts);
    }
    return posts;
}

// ---------- Friends list ----------
function showFriends() {
    document.getElementById("friendList").innerHTML = friendsByLogin().map(f => `
        <div class="d-flex align-items-center mb-2">
            ${avatar(f.name)}
            <div>
                <div>${safe(f.name)}</div>
                <small class="text-muted">${timeAgo(f.seen)}</small>
            </div>
        </div>`).join("");
}

// ---------- News feed ----------
function postHTML(p) {
    const friend = getFriends().find(f => f.name === p.author);
    const info = friend
        ? "Last login " + timeAgo(friend.seen)
        : timeAgo(p.at) + " · shared with " + safe(p.audience);

    return `
    <div class="card mb-3">
        <div class="card-body">
            <div class="d-flex align-items-center mb-2">
                ${avatar(p.author)}
                <div>
                    <strong>${safe(p.author)}</strong><br>
                    <small class="text-muted">${info}</small>
                </div>
            </div>
            <p>${safe(p.text)}</p>
            <button class="btn btn-sm ${p.mine === "like" ? "btn-primary" : "btn-outline-primary"}" onclick="react('${p.id}', 'like')">
                <i class="bi bi-hand-thumbs-up"></i> Like ${p.likes}</button>
            <button class="btn btn-sm ${p.mine === "dislike" ? "btn-primary" : "btn-outline-primary"}" onclick="react('${p.id}', 'dislike')">
                <i class="bi bi-hand-thumbs-down"></i> Dislike ${p.dislikes}</button>
        </div>
    </div>`;
}

function showFeed() {
    const posts = getPosts();

    // my own posts first (newest on top)
    const mine = posts.filter(p => p.author === ME).reverse();

    // friend posts: the friend who logged in last comes first
    const seenOf = name => { const f = getFriends().find(x => x.name === name); return f ? f.seen : 0; };
    const others = posts.filter(p => p.author !== ME).sort((a, b) => seenOf(b.author) - seenOf(a.author));

    document.getElementById("feed").innerHTML = mine.concat(others).map(postHTML).join("");
}

// ---------- Like / Dislike ----------
// one reaction per post: the other button switches it, the same button again does nothing
function react(id, kind) {
    const posts = getPosts();
    const p = posts.find(x => x.id === id);
    if (p.mine === kind) return;

    // take back my old reaction first
    if (p.mine === "like") p.likes--;
    if (p.mine === "dislike") p.dislikes--;

    if (kind === "like") p.likes++; else p.dislikes++;
    p.mine = kind;

    save("posts", posts);
    showFeed();
}

// ---------- Share news ----------
function showChoices() {
    document.getElementById("friendChoices").innerHTML = getFriends().map((f, i) => `
        <div class="form-check form-check-inline">
            <input class="form-check-input friend-check" type="checkbox" id="c${i}" value="${safe(f.name)}">
            <label class="form-check-label" for="c${i}">${safe(f.name.split(" ")[0])}</label>
        </div>`).join("");
}

function toggleChoices() {
    const some = document.getElementById("someFriends").checked;
    document.getElementById("friendChoices").classList.toggle("d-none", !some);
}

function sharePost() {
    const text = document.getElementById("postText").value.trim();
    let audience = "All friends";

    if (text === "") {
        showAlert("Please write something first.", "warning");
        return;
    }

    if (document.getElementById("someFriends").checked) {
        const chosen = Array.from(document.querySelectorAll(".friend-check:checked")).map(c => c.value);
        if (chosen.length === 0) {
            showAlert("Please select at least one friend.", "warning");
            return;
        }
        audience = chosen.join(", ");
    }

    const posts = getPosts();
    posts.push({ id: "own" + Date.now(), author: ME, text: text, likes: 0, dislikes: 0, mine: null, audience: audience, at: Date.now() });
    save("posts", posts);

    document.getElementById("postText").value = "";
    showFeed();
    showAlert("Your news has been shared.", "success");
}

// ---------- Invite ----------
function showInvite() {
    const invited = load("invited", []);
    const people = OTHER_MEMBERS.filter(n => !getFriends().some(f => f.name === n));

    document.getElementById("inviteList").innerHTML = people.map(n => `
        <div class="d-flex align-items-center mb-2">
            ${avatar(n)}
            <div class="flex-grow-1">${safe(n)}</div>
            ${invited.includes(n)
                ? '<button class="btn btn-sm btn-secondary" disabled>Invited</button>'
                : `<button class="btn btn-sm btn-outline-primary" onclick="invite('${n}')">Invite</button>`}
        </div>`).join("");
}

function invite(name) {
    // the person has put me in the ignore list: request cannot be sent
    if (IGNORE_LIST.includes(name)) {
        showAlert(name + " has ignored you. Friend request cannot be sent.", "danger");
        return;
    }

    const invited = load("invited", []);
    invited.push(name);
    save("invited", invited);

    showInvite();
    showAlert("Friend request sent to " + name + ".", "success");
}

// ---------- Start ----------
showFriends();
showFeed();
showChoices();
showInvite();
